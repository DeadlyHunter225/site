<?php
header("Location:https://www.allianz.fr/mon-espace-client/");
?>